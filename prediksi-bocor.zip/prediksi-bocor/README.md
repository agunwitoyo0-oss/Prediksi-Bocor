# Prediksi Bocor

Aplikasi Android untuk prediksi angka 4D/3D/2D menggunakan 4 metode tradisional (Mistik Lama, Mistik Baru, Indeks, Taysen) yang digabungkan dengan algoritma AI ensemble.

## Fitur

- Input: 4 digit angka terakhir keluar
- Output:
  - Angka Ikut (4 digit)
  - Angka Main (6 digit)
  - Colok Bebas (2 digit)
  - 4D — 5 pasang
  - 3D — 5 pasang
  - 2D — 10 pasang
- Rincian per metode (Mistik Lama, Mistik Baru, Indeks, Taysen)
- Tampilan dark mode profesional

## Cara Menjalankan (Development)

Butuh Node.js 20+ dan pnpm.

```bash
pnpm install
pnpm start
```

Lalu scan QR code dengan **Expo Go** (Android) di Play Store.

## Build APK Android

Gunakan **EAS Build** dari Expo (gratis untuk akun personal):

```bash
npm install -g eas-cli
eas login
eas build -p android --profile preview
```

EAS akan menghasilkan file `.apk` yang bisa diinstal di HP Android.

## Cara Upload ke GitHub

Lihat file `PANDUAN_GITHUB.md` untuk panduan langkah demi langkah.

## Disclaimer

Aplikasi ini dibuat untuk hiburan dan edukasi. Tidak ada jaminan keakuratan prediksi. Gunakan dengan bijak.
