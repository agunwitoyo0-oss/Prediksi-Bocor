export type PredictionResult = {
  angkaIkut: number[];
  angkaMain: number[];
  colokBebas: number[];
  d4: string[];
  d3: string[];
  d2: string[];
  scores: Record<number, number>;
  methodBreakdown: {
    mistikLama: number[];
    mistikBaru: number[];
    indeks: number[];
    taysen: number[];
  };
};

const MISTIK_LAMA: Record<number, number> = {
  0: 5, 1: 6, 2: 7, 3: 8, 4: 9,
  5: 0, 6: 1, 7: 2, 8: 3, 9: 4,
};

const MISTIK_BARU: Record<number, number> = {
  0: 9, 1: 8, 2: 7, 3: 6, 4: 5,
  5: 4, 6: 3, 7: 2, 8: 1, 9: 0,
};

const INDEKS: Record<number, number[]> = {
  0: [1, 2, 5], 1: [2, 3, 6], 2: [3, 4, 7], 3: [4, 5, 8],
  4: [5, 6, 9], 5: [6, 7, 0], 6: [7, 8, 1], 7: [8, 9, 2],
  8: [9, 0, 3], 9: [0, 1, 4],
};

const TAYSEN: Record<number, number[]> = {
  0: [3, 7], 1: [4, 8], 2: [5, 9], 3: [6, 0], 4: [7, 1],
  5: [8, 2], 6: [9, 3], 7: [0, 4], 8: [1, 5], 9: [2, 6],
};

function digitsOf(num: string): number[] {
  return num.split("").map((d) => parseInt(d, 10));
}

function mistikLamaPredict(digits: number[]): number[] {
  const out = new Set<number>();
  for (const d of digits) out.add(MISTIK_LAMA[d]!);
  for (const d of digits) out.add((d + 1) % 10);
  return Array.from(out);
}

function mistikBaruPredict(digits: number[]): number[] {
  const out = new Set<number>();
  for (const d of digits) out.add(MISTIK_BARU[d]!);
  for (const d of digits) out.add((d + 9) % 10);
  return Array.from(out);
}

function indeksPredict(digits: number[]): number[] {
  const out = new Set<number>();
  for (const d of digits) for (const v of INDEKS[d]!) out.add(v);
  const sum = digits.reduce((a, b) => a + b, 0) % 10;
  out.add(sum);
  return Array.from(out);
}

function taysenPredict(digits: number[]): number[] {
  const out = new Set<number>();
  for (const d of digits) for (const v of TAYSEN[d]!) out.add(v);
  const product = (digits[0]! * digits[3]! + digits[1]! * digits[2]!) % 10;
  out.add(product);
  return Array.from(out);
}

function aiEnsemble(
  methodResults: Record<string, number[]>,
  weights: Record<string, number>,
  lastDigits: number[],
): Record<number, number> {
  const scores: Record<number, number> = {};
  for (let i = 0; i < 10; i++) scores[i] = 0;

  for (const [method, nums] of Object.entries(methodResults)) {
    const w = weights[method] ?? 1;
    for (const n of nums) scores[n]! += w;
  }

  // AI heuristic boost: digits adjacent to last 4D get small bonus,
  // exact match gets penalty (less likely to repeat),
  // sum-mod-10 and digit-sum-of-sum get bonus.
  const sum = lastDigits.reduce((a, b) => a + b, 0);
  const sumMod = sum % 10;
  scores[sumMod]! += 0.8;
  const sumOfSum = String(sum).split("").reduce((a, b) => a + parseInt(b, 10), 0) % 10;
  scores[sumOfSum]! += 0.6;

  for (const d of lastDigits) {
    scores[(d + 1) % 10]! += 0.3;
    scores[(d + 9) % 10]! += 0.3;
    scores[d]! -= 0.4;
  }

  // Pythagorean-like: differences
  for (let i = 0; i < lastDigits.length - 1; i++) {
    const diff = Math.abs(lastDigits[i]! - lastDigits[i + 1]!);
    scores[diff]! += 0.5;
  }

  return scores;
}

function topN(scores: Record<number, number>, n: number, exclude: number[] = []): number[] {
  const ex = new Set(exclude);
  return Object.entries(scores)
    .map(([k, v]) => ({ k: parseInt(k, 10), v }))
    .filter((x) => !ex.has(x.k))
    .sort((a, b) => b.v - a.v || a.k - b.k)
    .slice(0, n)
    .map((x) => x.k);
}

function pickPairs(pool: number[], length: number, count: number, scores: Record<number, number>): string[] {
  const result = new Set<string>();
  const sortedPool = [...pool].sort((a, b) => (scores[b] ?? 0) - (scores[a] ?? 0));

  // Generate combinations using top scoring digits
  const generate = (current: string, depth: number) => {
    if (result.size >= count) return;
    if (depth === length) {
      result.add(current);
      return;
    }
    for (const d of sortedPool) {
      if (result.size >= count) return;
      generate(current + String(d), depth + 1);
    }
  };

  // Smart generation: prioritize sum-balanced combinations
  const all: { combo: string; score: number }[] = [];
  const recurse = (current: string, depth: number, scoreSum: number) => {
    if (depth === length) {
      all.push({ combo: current, score: scoreSum });
      return;
    }
    for (const d of sortedPool) {
      recurse(current + String(d), depth + 1, scoreSum + (scores[d] ?? 0));
    }
  };
  recurse("", 0, 0);
  all.sort((a, b) => b.score - a.score);

  for (const item of all) {
    if (result.size >= count) break;
    result.add(item.combo);
  }

  if (result.size < count) generate("", 0);

  return Array.from(result).slice(0, count);
}

export function predict(lastFourDigit: string): PredictionResult {
  if (!/^\d{4}$/.test(lastFourDigit)) {
    throw new Error("Input harus 4 digit angka (0-9).");
  }

  const digits = digitsOf(lastFourDigit);

  const ml = mistikLamaPredict(digits);
  const mb = mistikBaruPredict(digits);
  const ix = indeksPredict(digits);
  const ts = taysenPredict(digits);

  const weights = { mistikLama: 1.0, mistikBaru: 1.1, indeks: 1.3, taysen: 1.2 };
  const scores = aiEnsemble(
    { mistikLama: ml, mistikBaru: mb, indeks: ix, taysen: ts },
    weights,
    digits,
  );

  const angkaIkut = topN(scores, 4);
  const angkaMain = topN(scores, 6);
  const colokBebas = topN(scores, 2);

  // For 4D/3D/2D pools, use top 5 digits
  const poolBig = topN(scores, 6);
  const poolMid = topN(scores, 5);
  const poolSmall = topN(scores, 5);

  const d4 = pickPairs(poolBig, 4, 5, scores);
  const d3 = pickPairs(poolMid, 3, 5, scores);
  const d2 = pickPairs(poolSmall, 2, 10, scores);

  return {
    angkaIkut,
    angkaMain,
    colokBebas,
    d4,
    d3,
    d2,
    scores,
    methodBreakdown: {
      mistikLama: ml.sort((a, b) => a - b),
      mistikBaru: mb.sort((a, b) => a - b),
      indeks: ix.sort((a, b) => a - b),
      taysen: ts.sort((a, b) => a - b),
    },
  };
}
