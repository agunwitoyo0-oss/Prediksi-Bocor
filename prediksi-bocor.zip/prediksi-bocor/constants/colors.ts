const colors = {
  light: {
    text: "#f5f5f7",
    tint: "#d4af37",

    background: "#0a0e1a",
    foreground: "#f5f5f7",

    card: "#131829",
    cardForeground: "#f5f5f7",

    primary: "#d4af37",
    primaryForeground: "#0a0e1a",

    secondary: "#1c2238",
    secondaryForeground: "#f5f5f7",

    muted: "#1c2238",
    mutedForeground: "#8a93b0",

    accent: "#10b981",
    accentForeground: "#0a0e1a",

    destructive: "#ef4444",
    destructiveForeground: "#ffffff",

    border: "#252b42",
    input: "#1c2238",
  },
  radius: 16,
};

export default colors;
