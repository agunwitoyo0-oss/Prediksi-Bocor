# Panduan Upload ke GitHub

Ikuti langkah berikut untuk meng-upload aplikasi **Prediksi Bocor** ke akun GitHub Anda.

## A. Persiapan (Sekali Saja)

1. **Buat akun GitHub** di https://github.com (gratis).
2. **Install Git** di komputer Anda:
   - Windows: https://git-scm.com/download/win
   - Mac: `brew install git`
   - Linux: `sudo apt install git`
3. **Login Git** di terminal/CMD:
   ```bash
   git config --global user.name "Nama Anda"
   git config --global user.email "email@anda.com"
   ```

## B. Cara 1 — Upload Lewat Browser (Paling Mudah, Tanpa Git)

1. Login ke GitHub.
2. Klik tombol **"+"** kanan atas → **New repository**.
3. Isi:
   - **Repository name**: `prediksi-bocor`
   - **Description**: Aplikasi prediksi angka 4D
   - Pilih **Public** (atau Private jika ingin pribadi)
   - **JANGAN** centang "Add a README"
4. Klik **Create repository**.
5. Di halaman repo kosong, klik link **"uploading an existing file"**.
6. Ekstrak file `prediksi-bocor.zip` di komputer Anda.
7. **Drag-and-drop** SEMUA isi folder yang sudah diekstrak ke halaman GitHub (jangan upload folder `node_modules` jika ada).
8. Tunggu sampai semua file terupload, lalu di bagian bawah:
   - **Commit message**: `Initial commit`
   - Klik **Commit changes**.
9. Selesai! Repo Anda sudah online.

## C. Cara 2 — Upload Lewat Git Command Line

1. Buat repo kosong di GitHub (sama seperti langkah B.1–B.4).
2. Salin URL repo Anda, contoh: `https://github.com/USERNAME/prediksi-bocor.git`
3. Ekstrak `prediksi-bocor.zip`, lalu buka terminal di folder hasil ekstrak.
4. Jalankan perintah berikut satu per satu:

   ```bash
   git init
   git add .
   git commit -m "Initial commit"
   git branch -M main
   git remote add origin https://github.com/USERNAME/prediksi-bocor.git
   git push -u origin main
   ```

5. Saat diminta login, masukkan username GitHub dan **Personal Access Token** (bukan password biasa).
   - Cara membuat token: GitHub → Settings → Developer settings → Personal access tokens → Tokens (classic) → Generate new token (centang `repo`).

## D. Build APK Android Otomatis dari GitHub

Setelah repo terupload, Anda bisa build APK secara otomatis dengan **GitHub Actions + EAS Build**:

1. Buat akun gratis di https://expo.dev
2. Di terminal lokal:
   ```bash
   npm install -g eas-cli
   eas login
   eas build:configure
   eas build -p android --profile preview
   ```
3. Tunggu 10–20 menit, EAS akan kirim link download `.apk` siap install di Android.

## E. Update Kode di GitHub

Setelah perubahan kode:

```bash
git add .
git commit -m "Update fitur xxx"
git push
```

## F. Bantuan

- Dokumentasi GitHub: https://docs.github.com
- Dokumentasi Expo: https://docs.expo.dev
- Dokumentasi EAS Build: https://docs.expo.dev/build/introduction/

Selamat mencoba!
