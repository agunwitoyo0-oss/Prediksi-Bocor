import { Feather } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import React, { useMemo, useState } from "react";
import {
  ActivityIndicator,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { useColors } from "@/hooks/useColors";
import { predict, type PredictionResult } from "@/lib/predictor";

export default function HomeScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<PredictionResult | null>(null);
  const [error, setError] = useState<string | null>(null);

  const isValid = useMemo(() => /^\d{4}$/.test(input), [input]);

  const handlePredict = async () => {
    if (!isValid) {
      setError("Masukkan tepat 4 digit angka (0-9).");
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error).catch(() => {});
      return;
    }
    setError(null);
    setLoading(true);
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium).catch(() => {});

    setTimeout(() => {
      try {
        const r = predict(input);
        setResult(r);
        Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success).catch(() => {});
      } catch (e) {
        setError(e instanceof Error ? e.message : "Terjadi kesalahan");
      } finally {
        setLoading(false);
      }
    }, 700);
  };

  const handleReset = () => {
    setInput("");
    setResult(null);
    setError(null);
    Haptics.selectionAsync().catch(() => {});
  };

  return (
    <View style={[styles.root, { backgroundColor: colors.background }]}>
      <ScrollView
        contentContainerStyle={{
          paddingTop: insets.top + 24,
          paddingBottom: insets.bottom + 40,
          paddingHorizontal: 20,
        }}
        keyboardShouldPersistTaps="handled"
        showsVerticalScrollIndicator={false}
      >
        {/* Header */}
        <View style={styles.header}>
          <View style={[styles.logoBadge, { backgroundColor: colors.primary }]}>
            <Feather name="zap" size={20} color={colors.primaryForeground} />
          </View>
          <View style={{ flex: 1 }}>
            <Text style={[styles.brand, { color: colors.foreground }]}>Prediksi Bocor</Text>
            <Text style={[styles.subtitle, { color: colors.mutedForeground }]}>
              AI Ensemble · 4 Metode Prediksi
            </Text>
          </View>
        </View>

        {/* Input Card */}
        <View style={[styles.card, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <Text style={[styles.cardLabel, { color: colors.mutedForeground }]}>
            ANGKA TERAKHIR KELUAR (4 DIGIT)
          </Text>
          <TextInput
            value={input}
            onChangeText={(t) => setInput(t.replace(/[^0-9]/g, "").slice(0, 4))}
            keyboardType="number-pad"
            maxLength={4}
            placeholder="0000"
            placeholderTextColor={colors.mutedForeground + "60"}
            style={[
              styles.input,
              {
                color: colors.primary,
                borderColor: isValid ? colors.primary : colors.border,
                backgroundColor: colors.background,
              },
            ]}
            textAlign="center"
          />

          {error ? (
            <View style={styles.errorRow}>
              <Feather name="alert-circle" size={14} color={colors.destructive} />
              <Text style={[styles.errorText, { color: colors.destructive }]}>{error}</Text>
            </View>
          ) : null}

          <View style={styles.buttonRow}>
            <Pressable
              onPress={handlePredict}
              disabled={loading}
              style={({ pressed }) => [
                styles.primaryButton,
                {
                  backgroundColor: colors.primary,
                  opacity: pressed || loading ? 0.85 : 1,
                },
              ]}
            >
              {loading ? (
                <ActivityIndicator color={colors.primaryForeground} />
              ) : (
                <>
                  <Feather name="cpu" size={16} color={colors.primaryForeground} />
                  <Text style={[styles.primaryButtonText, { color: colors.primaryForeground }]}>
                    Generate Prediksi
                  </Text>
                </>
              )}
            </Pressable>
            <Pressable
              onPress={handleReset}
              style={({ pressed }) => [
                styles.iconButton,
                {
                  backgroundColor: colors.secondary,
                  opacity: pressed ? 0.7 : 1,
                },
              ]}
            >
              <Feather name="rotate-ccw" size={16} color={colors.foreground} />
            </Pressable>
          </View>
        </View>

        {/* Results */}
        {result ? (
          <View style={{ gap: 16, marginTop: 20 }}>
            <SectionTitle icon="target" title="Hasil Prediksi" colors={colors} />

            <ChipCard
              label="ANGKA IKUT"
              values={result.angkaIkut.map(String)}
              accent={colors.primary}
              colors={colors}
            />
            <ChipCard
              label="ANGKA MAIN"
              values={result.angkaMain.map(String)}
              accent={colors.accent}
              colors={colors}
            />
            <ChipCard
              label="COLOK BEBAS"
              values={result.colokBebas.map(String)}
              accent={"#f97316"}
              colors={colors}
            />

            <PairCard label="4D · 5 Pasang" values={result.d4} colors={colors} />
            <PairCard label="3D · 5 Pasang" values={result.d3} colors={colors} />
            <PairCard label="2D · 10 Pasang" values={result.d2} columns={5} colors={colors} />

            <SectionTitle icon="layers" title="Rincian Metode" colors={colors} />
            <MethodBreakdown breakdown={result.methodBreakdown} colors={colors} />

            <View style={[styles.disclaimer, { borderColor: colors.border }]}>
              <Feather name="info" size={12} color={colors.mutedForeground} />
              <Text style={[styles.disclaimerText, { color: colors.mutedForeground }]}>
                Prediksi bersifat hiburan. Tidak ada jaminan keakuratan 100%.
              </Text>
            </View>
          </View>
        ) : (
          <EmptyState colors={colors} />
        )}
      </ScrollView>
    </View>
  );
}

type ColorTheme = ReturnType<typeof useColors>;

function SectionTitle({ icon, title, colors }: { icon: keyof typeof Feather.glyphMap; title: string; colors: ColorTheme }) {
  return (
    <View style={styles.sectionTitleRow}>
      <Feather name={icon} size={14} color={colors.primary} />
      <Text style={[styles.sectionTitle, { color: colors.foreground }]}>{title}</Text>
      <View style={[styles.sectionLine, { backgroundColor: colors.border }]} />
    </View>
  );
}

function ChipCard({
  label,
  values,
  accent,
  colors,
}: {
  label: string;
  values: string[];
  accent: string;
  colors: ColorTheme;
}) {
  return (
    <View style={[styles.card, { backgroundColor: colors.card, borderColor: colors.border, paddingVertical: 16 }]}>
      <Text style={[styles.cardLabel, { color: colors.mutedForeground, marginBottom: 12 }]}>{label}</Text>
      <View style={styles.chipRow}>
        {values.map((v, i) => (
          <View
            key={`${v}-${i}`}
            style={[
              styles.chip,
              { backgroundColor: accent + "1A", borderColor: accent + "55" },
            ]}
          >
            <Text style={[styles.chipText, { color: accent }]}>{v}</Text>
          </View>
        ))}
      </View>
    </View>
  );
}

function PairCard({
  label,
  values,
  columns = 5,
  colors,
}: {
  label: string;
  values: string[];
  columns?: number;
  colors: ColorTheme;
}) {
  return (
    <View style={[styles.card, { backgroundColor: colors.card, borderColor: colors.border, paddingVertical: 16 }]}>
      <Text style={[styles.cardLabel, { color: colors.mutedForeground, marginBottom: 12 }]}>{label}</Text>
      <View style={styles.pairGrid}>
        {values.map((v, i) => (
          <View
            key={`${v}-${i}`}
            style={[
              styles.pairCell,
              {
                width: `${100 / columns - 2}%`,
                backgroundColor: colors.secondary,
                borderColor: colors.border,
              },
            ]}
          >
            <Text style={[styles.pairText, { color: colors.foreground }]}>{v}</Text>
          </View>
        ))}
      </View>
    </View>
  );
}

function MethodBreakdown({
  breakdown,
  colors,
}: {
  breakdown: PredictionResult["methodBreakdown"];
  colors: ColorTheme;
}) {
  const methods: { key: keyof typeof breakdown; name: string; icon: keyof typeof Feather.glyphMap }[] = [
    { key: "mistikLama", name: "Mistik Lama", icon: "book" },
    { key: "mistikBaru", name: "Mistik Baru", icon: "book-open" },
    { key: "indeks", name: "Indeks", icon: "bar-chart-2" },
    { key: "taysen", name: "Taysen", icon: "compass" },
  ];

  return (
    <View style={{ gap: 10 }}>
      {methods.map((m) => (
        <View
          key={m.key}
          style={[
            styles.methodRow,
            { backgroundColor: colors.card, borderColor: colors.border },
          ]}
        >
          <View style={[styles.methodIcon, { backgroundColor: colors.secondary }]}>
            <Feather name={m.icon} size={14} color={colors.primary} />
          </View>
          <View style={{ flex: 1 }}>
            <Text style={[styles.methodName, { color: colors.foreground }]}>{m.name}</Text>
            <Text style={[styles.methodValues, { color: colors.mutedForeground }]}>
              {breakdown[m.key].join(" · ")}
            </Text>
          </View>
        </View>
      ))}
    </View>
  );
}

function EmptyState({ colors }: { colors: ColorTheme }) {
  return (
    <View style={[styles.empty, { borderColor: colors.border }]}>
      <View style={[styles.emptyIcon, { backgroundColor: colors.secondary }]}>
        <Feather name="trending-up" size={28} color={colors.primary} />
      </View>
      <Text style={[styles.emptyTitle, { color: colors.foreground }]}>Siap Memprediksi</Text>
      <Text style={[styles.emptyText, { color: colors.mutedForeground }]}>
        Masukkan 4 digit angka terakhir keluar, lalu tekan Generate. Sistem akan
        menggabungkan Mistik Lama, Mistik Baru, Indeks, dan Taysen melalui AI ensemble.
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1 },
  header: {
    flexDirection: "row",
    alignItems: "center",
    gap: 12,
    marginBottom: 24,
  },
  logoBadge: {
    width: 44,
    height: 44,
    borderRadius: 12,
    alignItems: "center",
    justifyContent: "center",
  },
  brand: { fontSize: 22, fontFamily: "Inter_700Bold", letterSpacing: -0.5 },
  subtitle: { fontSize: 12, fontFamily: "Inter_500Medium", marginTop: 2 },
  card: {
    borderRadius: 16,
    borderWidth: 1,
    padding: 18,
  },
  cardLabel: {
    fontSize: 11,
    fontFamily: "Inter_600SemiBold",
    letterSpacing: 1.2,
  },
  input: {
    fontSize: 42,
    fontFamily: "Inter_700Bold",
    letterSpacing: 12,
    borderWidth: 2,
    borderRadius: 12,
    paddingVertical: 18,
    marginTop: 10,
  },
  errorRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
    marginTop: 10,
  },
  errorText: { fontSize: 12, fontFamily: "Inter_500Medium" },
  buttonRow: { flexDirection: "row", gap: 10, marginTop: 14 },
  primaryButton: {
    flex: 1,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 8,
    paddingVertical: 14,
    borderRadius: 12,
  },
  primaryButtonText: { fontSize: 14, fontFamily: "Inter_600SemiBold" },
  iconButton: {
    width: 48,
    alignItems: "center",
    justifyContent: "center",
    borderRadius: 12,
  },
  sectionTitleRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
    marginTop: 8,
  },
  sectionTitle: { fontSize: 13, fontFamily: "Inter_600SemiBold" },
  sectionLine: { flex: 1, height: 1 },
  chipRow: { flexDirection: "row", flexWrap: "wrap", gap: 8 },
  chip: {
    minWidth: 44,
    paddingHorizontal: 14,
    paddingVertical: 10,
    borderRadius: 10,
    borderWidth: 1,
    alignItems: "center",
  },
  chipText: { fontSize: 18, fontFamily: "Inter_700Bold", letterSpacing: 1 },
  pairGrid: { flexDirection: "row", flexWrap: "wrap", gap: 6, justifyContent: "flex-start" },
  pairCell: {
    paddingVertical: 12,
    borderRadius: 10,
    borderWidth: 1,
    alignItems: "center",
    marginRight: 6,
    marginBottom: 6,
  },
  pairText: { fontSize: 16, fontFamily: "Inter_600SemiBold", letterSpacing: 2 },
  methodRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 12,
    padding: 12,
    borderRadius: 12,
    borderWidth: 1,
  },
  methodIcon: {
    width: 32,
    height: 32,
    borderRadius: 8,
    alignItems: "center",
    justifyContent: "center",
  },
  methodName: { fontSize: 13, fontFamily: "Inter_600SemiBold" },
  methodValues: { fontSize: 12, fontFamily: "Inter_500Medium", marginTop: 2 },
  empty: {
    marginTop: 24,
    padding: 32,
    borderRadius: 16,
    borderWidth: 1,
    borderStyle: "dashed",
    alignItems: "center",
    gap: 12,
  },
  emptyIcon: {
    width: 60,
    height: 60,
    borderRadius: 16,
    alignItems: "center",
    justifyContent: "center",
  },
  emptyTitle: { fontSize: 16, fontFamily: "Inter_600SemiBold" },
  emptyText: {
    fontSize: 13,
    fontFamily: "Inter_400Regular",
    textAlign: "center",
    lineHeight: 19,
  },
  disclaimer: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
    padding: 12,
    borderRadius: 10,
    borderWidth: 1,
    marginTop: 4,
  },
  disclaimerText: { fontSize: 11, fontFamily: "Inter_400Regular", flex: 1 },
});
